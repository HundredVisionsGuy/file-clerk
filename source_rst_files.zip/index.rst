.. file-clerk documentation master file, created by
   sphinx-quickstart on Mon Jul 18 14:03:04 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


Welcome to file-clerk's documentation!
======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   intro
   file_clerk
   examples


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
